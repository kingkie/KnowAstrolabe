# API diff: SkiaSharp.Views.Gtk.dll

## SkiaSharp.Views.Gtk.dll

> No changes.
