# API diff: SkiaSharp.Views.Gtk.dll

## SkiaSharp.Views.Gtk.dll

> Assembly Version Changed: 2.80.0.0 vs 1.68.0.0

