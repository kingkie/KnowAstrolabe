# API diff: SkiaSharp.Views.Maui.Controls.dll

## SkiaSharp.Views.Maui.Controls.dll

> Assembly Version Changed: 3.0.0.0 vs 2.88.0.0

### Namespace SkiaSharp.Views.Maui.Controls

#### Type Changed: SkiaSharp.Views.Maui.Controls.SKCanvasView

Removed interface:

```csharp
ISKCanvasViewController
```


#### Type Changed: SkiaSharp.Views.Maui.Controls.SKGLView

Removed interface:

```csharp
ISKGLViewController
```


#### Removed Type SkiaSharp.Views.Maui.Controls.ISKCanvasViewController
#### Removed Type SkiaSharp.Views.Maui.Controls.ISKGLViewController

