# API diff: SkiaSharp.Views.Maui.Core.dll

## SkiaSharp.Views.Maui.Core.dll

> No changes.
