# API diff: SkiaSharp.Views.Desktop.Common.dll

## SkiaSharp.Views.Desktop.Common.dll

> Assembly Version Changed: 2.80.0.0 vs 1.68.0.0

