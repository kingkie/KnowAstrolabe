# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

### Namespace SkiaSharp.Views.Forms

#### Type Changed: SkiaSharp.Views.Forms.SKCanvasView

Added field:

```csharp
public static Xamarin.Forms.BindableProperty IgnorePixelScalingProperty;
```

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



