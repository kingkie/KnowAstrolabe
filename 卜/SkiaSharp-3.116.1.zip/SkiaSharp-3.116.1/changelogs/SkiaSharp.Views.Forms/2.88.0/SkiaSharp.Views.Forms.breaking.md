# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

> Assembly Version Changed: 2.88.0.0 vs 2.80.0.0

### Namespace SkiaSharp.Views.Forms

#### Type Changed: SkiaSharp.Views.Forms.Resource

#### Type Changed: SkiaSharp.Views.Forms.Resource.Id

Removed fields:

```csharp
public static int save_image_matrix;
public static int save_scale_type;
```


#### Type Changed: SkiaSharp.Views.Forms.Resource.String

Removed fields:

```csharp
public static int abc_font_family_body_1_material;
public static int abc_font_family_body_2_material;
public static int abc_font_family_button_material;
public static int abc_font_family_caption_material;
public static int abc_font_family_display_1_material;
public static int abc_font_family_display_2_material;
public static int abc_font_family_display_3_material;
public static int abc_font_family_display_4_material;
public static int abc_font_family_headline_material;
public static int abc_font_family_menu_material;
public static int abc_font_family_subhead_material;
public static int abc_font_family_title_material;
```


#### Type Changed: SkiaSharp.Views.Forms.Resource.Style

Removed field:

```csharp
public static int collectionViewStyle;
```




