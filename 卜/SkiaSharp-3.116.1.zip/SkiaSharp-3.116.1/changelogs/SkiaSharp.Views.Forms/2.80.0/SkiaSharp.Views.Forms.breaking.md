# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

> Assembly Version Changed: 2.80.0.0 vs 1.68.0.0

### Removed Namespace SkiaSharp.Views.Forms.SkiaSharp_Views_Forms_UWP_XamlTypeInfo


#### Removed Type SkiaSharp.Views.Forms.SkiaSharp_Views_Forms_UWP_XamlTypeInfo.XamlMetaDataProvider
