# API diff: SkiaSharp.Views.Forms.dll

## SkiaSharp.Views.Forms.dll

### Namespace SkiaSharp.Views.Forms

#### Type Changed: SkiaSharp.Views.Forms.SKGLView

Added property:

```csharp
public SkiaSharp.GRContext GRContext { get; }
```



