# API diff: SkiaSharp.Views.Blazor.dll

## SkiaSharp.Views.Blazor.dll

> Assembly Version Changed: 3.0.0.0 vs 2.88.0.0

### Namespace SkiaSharp.Views.Blazor

#### Type Changed: SkiaSharp.Views.Blazor.SKCanvasView

Added property:

```csharp
public double Dpi { get; }
```


#### Type Changed: SkiaSharp.Views.Blazor.SKGLView

Added property:

```csharp
public double Dpi { get; }
```



