# API diff: SkiaSharp.Views.Blazor.dll

## SkiaSharp.Views.Blazor.dll

> No changes.
