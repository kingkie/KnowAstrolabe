# API diff: SkiaSharp.Views.Gtk3.dll

## SkiaSharp.Views.Gtk3.dll

> Assembly Version Changed: 3.0.0.0 vs 2.88.0.0

