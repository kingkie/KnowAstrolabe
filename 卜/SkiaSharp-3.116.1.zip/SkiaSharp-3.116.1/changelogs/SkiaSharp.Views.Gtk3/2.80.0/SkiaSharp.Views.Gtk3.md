# API diff: SkiaSharp.Views.Gtk3.dll

## SkiaSharp.Views.Gtk3.dll

> Assembly Version Changed: 2.80.0.0 vs 1.68.0.0

