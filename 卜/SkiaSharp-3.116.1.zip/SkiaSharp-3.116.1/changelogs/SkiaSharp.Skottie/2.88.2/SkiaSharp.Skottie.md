# API diff: SkiaSharp.Skottie.dll

## SkiaSharp.Skottie.dll

> No changes.
