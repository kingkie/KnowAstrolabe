# API diff: SkiaSharp.SceneGraph.dll

## SkiaSharp.SceneGraph.dll

> No changes.
