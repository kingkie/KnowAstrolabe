# API diff: SkiaSharp.Views.WindowsForms.dll

## SkiaSharp.Views.WindowsForms.dll

> No changes.
