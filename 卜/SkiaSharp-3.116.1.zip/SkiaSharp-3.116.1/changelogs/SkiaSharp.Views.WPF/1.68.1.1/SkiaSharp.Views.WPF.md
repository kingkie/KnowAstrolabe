# API diff: SkiaSharp.Views.WPF.dll

## SkiaSharp.Views.WPF.dll

> No changes.
