# API diff: HarfBuzzSharp.dll

## HarfBuzzSharp.dll

> No changes.
