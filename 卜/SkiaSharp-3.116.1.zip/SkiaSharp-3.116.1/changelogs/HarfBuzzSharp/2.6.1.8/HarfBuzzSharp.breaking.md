# API diff: HarfBuzzSharp.dll

## HarfBuzzSharp.dll

### Namespace HarfBuzzSharp

#### Type Changed: HarfBuzzSharp.OpenTypeMetrics

Modified base type:

```diff
-System.ValueType
+System.Object
```

Removed constructor:

```csharp
public OpenTypeMetrics (IntPtr font);
```



