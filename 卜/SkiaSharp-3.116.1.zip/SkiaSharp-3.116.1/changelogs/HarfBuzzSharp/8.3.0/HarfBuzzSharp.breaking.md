# API diff: HarfBuzzSharp.dll

## HarfBuzzSharp.dll

### Namespace HarfBuzzSharp

#### Type Changed: HarfBuzzSharp.Blob

Removed method:

```csharp
public System.ReadOnlySpan<byte> AsSpan ();
```



