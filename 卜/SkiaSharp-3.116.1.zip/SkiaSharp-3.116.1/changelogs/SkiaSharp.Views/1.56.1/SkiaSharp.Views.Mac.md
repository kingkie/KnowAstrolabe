# API diff: SkiaSharp.Views.Mac.dll

## SkiaSharp.Views.Mac.dll

> No changes.
