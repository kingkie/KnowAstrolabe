# API diff: SkiaSharp.Views.tvOS.dll

## SkiaSharp.Views.tvOS.dll

> Assembly Version Changed: 1.56.0.0 vs 1.55.0.0

### Namespace SkiaSharp.Views.tvOS

#### Type Changed: SkiaSharp.Views.tvOS.Extensions

Removed methods:

```csharp
public static System.Drawing.Color ToDrawingColor (this SkiaSharp.SKColor color);
public static SkiaSharp.SKColor ToSKColor (this System.Drawing.Color color);
```



