# API diff: SkiaSharp.Views.WPF.dll

## SkiaSharp.Views.WPF.dll

> Assembly Version Changed: 1.56.0.0 vs 1.55.0.0

