# API diff: SkiaSharp.Views.iOS.dll

## SkiaSharp.Views.iOS.dll

### Namespace SkiaSharp.Views.iOS

#### Type Changed: SkiaSharp.Views.iOS.SKCanvasLayer

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```


#### Type Changed: SkiaSharp.Views.iOS.SKCanvasView

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



