# API diff: SkiaSharp.Views.UWP.dll

## SkiaSharp.Views.UWP.dll

### Namespace SkiaSharp.Views.UWP

#### Type Changed: SkiaSharp.Views.UWP.SKXamlCanvas

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



