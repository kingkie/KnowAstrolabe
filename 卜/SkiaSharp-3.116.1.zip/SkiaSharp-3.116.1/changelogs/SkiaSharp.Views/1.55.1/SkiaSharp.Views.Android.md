# API diff: SkiaSharp.Views.Android.dll

## SkiaSharp.Views.Android.dll

### Namespace SkiaSharp.Views.Android

#### Type Changed: SkiaSharp.Views.Android.SKCanvasView

Added property:

```csharp
public bool IgnorePixelScaling { get; set; }
```



